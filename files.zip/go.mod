module fetch-pr-commentary

go 1.22

// run `go get github.com/charmbracelet/huh@latest && go mod tidy` to pin huh
